import React, { useEffect, useState } from 'react';
import { doc, onSnapshot } from "firebase/firestore";
import { db } from './firebase';
import { MetalRates, DEFAULT_RATES } from './types';
import RateCard from './components/RateCard';
import AdminPanel from './components/AdminPanel';
import ChatWidget from './components/ChatWidget';

function App() {
  const [rates, setRates] = useState<MetalRates>(DEFAULT_RATES);
  const [loading, setLoading] = useState(true);
  const [showAdmin, setShowAdmin] = useState(false);
  const [permissionError, setPermissionError] = useState(false);

  useEffect(() => {
    // Subscribe to Firestore updates
    const unsub = onSnapshot(doc(db, "rates", "current"), (doc) => {
      setLoading(false);
      setPermissionError(false);
      if (doc.exists()) {
        setRates(doc.data() as MetalRates);
      } else {
        // Doc doesn't exist, we fallback to default rates which are already set
        console.log("No live data found, using defaults");
      }
    }, (error) => {
      setLoading(false);
      console.error("Firestore Read Error:", error);
      if (error.code === 'permission-denied') {
        setPermissionError(true);
      }
    });

    return () => unsub();
  }, []);

  // Keyboard shortcut to open admin panel (Ctrl + Shift + A)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && e.key === 'A') {
        setShowAdmin(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleShare = async () => {
    const rateText = `*Gulab Ornament X Madhuri Jewellers*\n\nLive Rates:\nSilver Batiya: ₹${rates.silverBatiya}\nSilver RTGS: ₹${rates.silverRtgsBatiya}\nGold Bread 99.50: ₹${rates.goldBread9950}\nGold Bread 99.99: ₹${rates.goldBreadNumber9999}\nGold RTGS: ₹${rates.goldRtgsNumber9999}\n\nVisit us for live updates!`;
    const fullShareText = `${rateText}\n${window.location.href}`;
    
    // 1. Try Native Share API (Mobile)
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Gulab Ornament Live Rates',
          text: rateText,
          url: window.location.href,
        });
        return; // Success
      } catch (error) {
        console.log('Native share failed or cancelled:', error);
        // If it was just cancelled by user, stop here.
        if ((error as any).name === 'AbortError') return;
      }
    }

    // Helper function for clipboard operations
    const copyToClipboard = async (text: string): Promise<boolean> => {
      // Method A: Modern API
      // We check for clipboard existence. Note: 'writeText' can throw permission errors.
      if (navigator.clipboard && window.isSecureContext) {
        try {
          await navigator.clipboard.writeText(text);
          return true;
        } catch (err) {
          console.warn('Navigator clipboard failed (permission/context), trying fallback:', err);
          // Continue to fallback
        }
      }

      // Method B: Legacy Textarea
      try {
        const textArea = document.createElement("textarea");
        textArea.value = text;
        
        // Ensure element is part of document but hidden visually
        textArea.style.position = "fixed";
        textArea.style.left = "-9999px";
        textArea.style.top = "0";
        textArea.setAttribute('readonly', '');
        document.body.appendChild(textArea);
        
        textArea.focus();
        textArea.select();
        
        const successful = document.execCommand('copy');
        document.body.removeChild(textArea);
        return successful;
      } catch (err) {
        console.warn('ExecCommand failed:', err);
        return false;
      }
    };

    // 2. Execute Clipboard Logic
    const copied = await copyToClipboard(fullShareText);
    
    if (copied) {
      alert('Rates copied to clipboard!');
    } else {
      // 3. Final Fallback: WhatsApp Link
      // If native share AND clipboard both fail, assume we need an external app
      const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(fullShareText)}`;
      const newWindow = window.open(whatsappUrl, '_blank');
      if (!newWindow) {
         alert('Unable to share automatically. Please screenshot this page.');
      }
    }
  };

  const formattedDate = new Date(rates.lastUpdated).toLocaleDateString('en-IN', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
  });

  const formattedTime = new Date(rates.lastUpdated).toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit'
  });

  return (
    <div className="min-h-screen flex flex-col font-sans text-gray-800 bg-gray-50 overflow-x-hidden">
      
      {/* Navbar / Header */}
      <header className="bg-maroon-900 text-white shadow-lg sticky top-0 z-30">
        <div className="container mx-auto px-4 py-3 md:py-4 flex flex-row justify-between items-center">
          <div className="flex items-center space-x-3">
             <div className="w-10 h-10 md:w-12 md:h-12 rounded-full border-2 border-gold-400 flex items-center justify-center bg-maroon-800 shadow-md">
               <i className="fas fa-crown text-gold-400 text-lg md:text-xl"></i>
             </div>
             <div className="text-left leading-tight">
               <h1 className="text-base md:text-2xl font-serif font-bold tracking-wider text-gold-400 uppercase">
                 Gulab Ornament
               </h1>
               <div className="flex items-center gap-2">
                  <span className="text-[10px] md:text-sm text-gold-200 uppercase tracking-widest opacity-80">X Madhuri Jewellers</span>
               </div>
             </div>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={handleShare}
              className="bg-gradient-to-r from-gold-600 to-gold-500 hover:from-gold-500 hover:to-gold-400 text-white px-4 py-2 rounded-full text-sm md:text-base font-bold shadow-lg flex items-center gap-2 transform active:scale-95 transition-all"
            >
              <i className="fas fa-share-nodes"></i>
              <span className="hidden md:inline">Share</span>
            </button>
          </div>
        </div>
      </header>

      {/* Hero / Main Content */}
      <main className="flex-grow container mx-auto px-3 md:px-4 py-2 md:py-8">
        
        {/* Date & Status */}
        <div className="flex flex-row md:flex-col justify-between md:justify-center items-center mb-3 md:mb-8 bg-white md:bg-transparent p-2 md:p-0 rounded-lg shadow-sm md:shadow-none border border-gray-100 md:border-none">
          <div className="flex items-center gap-2">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-green-50 rounded-full text-green-700 text-xs md:text-sm font-bold border border-green-200">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
              <span>LIVE</span>
            </div>
            <span className="text-xs md:text-base text-gray-500 font-medium">
               {formattedDate}, {formattedTime}
            </span>
          </div>
          
          {permissionError && (
             <div className="text-[10px] text-yellow-600 bg-yellow-50 px-2 py-1 rounded border border-yellow-200">
               Demo Mode
             </div>
          )}
        </div>

        {/* Rate Cards Container - Compact Grid */}
        <div className="grid grid-cols-2 md:flex md:flex-wrap justify-center gap-3 md:gap-8 max-w-7xl mx-auto pb-4 md:pb-0">
          
          <div className="md:w-80 lg:w-96 flex-shrink-0">
            <RateCard 
              title="Silver Batiya" 
              purity="999 Fine" 
              price={rates.silverBatiya} 
              unit="1kg" 
              iconClass="fas fa-bars"
              trend="up"
              delay={100}
            />
          </div>

          <div className="md:w-80 lg:w-96 flex-shrink-0">
            <RateCard 
              title="Silver RTGS" 
              purity="999 RTGS" 
              price={rates.silverRtgsBatiya} 
              unit="1kg" 
              iconClass="fas fa-money-bill-wave"
              delay={150}
            />
          </div>
          
          <div className="md:w-80 lg:w-96 flex-shrink-0">
            <RateCard 
              title="Gold Bread" 
              purity="99.50%" 
              price={rates.goldBread9950} 
              unit="10g"
              iconClass="fas fa-cubes"
              trend="stable"
              delay={200}
            />
          </div>

          <div className="md:w-80 lg:w-96 flex-shrink-0">
            <RateCard 
              title="Gold Bread No." 
              purity="99.99%" 
              price={rates.goldBreadNumber9999} 
              unit="10g"
              iconClass="fas fa-cube"
              trend="up"
              delay={250}
            />
          </div>

          {/* Last item spans 2 cols on mobile for centered prominence */}
          <div className="col-span-2 md:col-span-1 md:w-80 lg:w-96 flex-shrink-0">
            <RateCard 
              title="Gold RTGS No." 
              purity="99.99% RTGS" 
              price={rates.goldRtgsNumber9999} 
              unit="10g"
              iconClass="fas fa-university"
              delay={300}
            />
          </div>

        </div>

        {/* Contact Section */}
        <div className="mt-6 md:mt-12 mb-8">
          <h2 className="text-center text-maroon-900 font-serif text-lg md:text-2xl font-bold mb-4 md:mb-8 uppercase tracking-widest relative">
            <span className="relative z-10 px-4 bg-gray-50">Contact Us</span>
            <div className="absolute top-1/2 left-0 w-full h-px bg-gold-300 -z-0"></div>
          </h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 md:gap-6 max-w-5xl mx-auto">
            {/* Gulab Ji */}
            <a href="tel:+919335660331" className="group select-none bg-white p-3 md:p-4 rounded-xl shadow-sm border border-gold-200 flex items-center space-x-3 md:space-x-4 hover:shadow-lg hover:border-gold-400 transition-all cursor-pointer">
              <div className="w-10 h-10 md:w-12 md:h-12 bg-maroon-50 rounded-full flex items-center justify-center text-maroon-800 group-hover:bg-maroon-100 transition-colors flex-shrink-0">
                <i className="fas fa-user-tie text-lg"></i>
              </div>
              <div className="flex-grow">
                <h3 className="font-bold text-gray-800 text-sm md:text-lg">Gulab Ji</h3>
                <p className="text-[10px] md:text-xs text-gold-600 font-bold uppercase tracking-wider mb-0.5">Proprietor</p>
                <div className="flex items-center text-maroon-900 font-mono text-sm md:text-base font-bold">
                   <i className="fas fa-phone-alt text-xs mr-2 opacity-50"></i>
                   9335660331
                </div>
              </div>
              <div className="text-gold-400 opacity-0 group-hover:opacity-100 transition-opacity">
                <i className="fas fa-chevron-right"></i>
              </div>
            </a>

            {/* Vikas Verma */}
            <a href="tel:+917499233028" className="group select-none bg-white p-3 md:p-4 rounded-xl shadow-sm border border-gold-200 flex items-center space-x-3 md:space-x-4 hover:shadow-lg hover:border-gold-400 transition-all cursor-pointer">
              <div className="w-10 h-10 md:w-12 md:h-12 bg-maroon-50 rounded-full flex items-center justify-center text-maroon-800 group-hover:bg-maroon-100 transition-colors flex-shrink-0">
                <i className="fas fa-phone text-lg"></i>
              </div>
              <div className="flex-grow">
                <h3 className="font-bold text-gray-800 text-sm md:text-lg">Vikas Verma</h3>
                <p className="text-[10px] md:text-xs text-gold-600 font-bold uppercase tracking-wider mb-0.5">Sales</p>
                <div className="flex items-center text-maroon-900 font-mono text-sm md:text-base font-bold">
                   <i className="fas fa-phone-alt text-xs mr-2 opacity-50"></i>
                   7499233028
                </div>
              </div>
               <div className="text-gold-400 opacity-0 group-hover:opacity-100 transition-opacity">
                <i className="fas fa-chevron-right"></i>
              </div>
            </a>

            {/* Nishant Verma */}
            <a href="tel:+917619996888" className="group select-none bg-white p-3 md:p-4 rounded-xl shadow-sm border border-gold-200 flex items-center space-x-3 md:space-x-4 hover:shadow-lg hover:border-gold-400 transition-all cursor-pointer">
              <div className="w-10 h-10 md:w-12 md:h-12 bg-maroon-50 rounded-full flex items-center justify-center text-maroon-800 group-hover:bg-maroon-100 transition-colors flex-shrink-0">
                <i className="fas fa-headset text-lg"></i>
              </div>
              <div className="flex-grow">
                <h3 className="font-bold text-gray-800 text-sm md:text-lg">Nishant Verma</h3>
                <p className="text-[10px] md:text-xs text-gold-600 font-bold uppercase tracking-wider mb-0.5">Support</p>
                <div className="flex items-center text-maroon-900 font-mono text-sm md:text-base font-bold">
                   <i className="fas fa-phone-alt text-xs mr-2 opacity-50"></i>
                   7619996888
                </div>
              </div>
               <div className="text-gold-400 opacity-0 group-hover:opacity-100 transition-opacity">
                <i className="fas fa-chevron-right"></i>
              </div>
            </a>
          </div>
        </div>

        {/* Desktop Info Section - Hidden on Mobile */}
        <div className="hidden md:grid mt-8 md:mt-16 grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto text-center md:text-left">
          <div className="p-6 bg-white rounded-lg shadow border-t-4 border-maroon-800">
             <div className="w-12 h-12 bg-maroon-100 rounded-full flex items-center justify-center text-maroon-800 mb-4 mx-auto md:mx-0">
               <i className="fas fa-check-circle text-xl"></i>
             </div>
             <h3 className="text-lg font-bold font-serif mb-2 text-gray-800">Certified Purity</h3>
             <p className="text-gray-600 text-sm">All our Silver Batiya and Gold Bread bars come with certified purity guarantees.</p>
          </div>
          <div className="p-6 bg-white rounded-lg shadow border-t-4 border-gold-500">
             <div className="w-12 h-12 bg-gold-100 rounded-full flex items-center justify-center text-gold-700 mb-4 mx-auto md:mx-0">
               <i className="fas fa-hand-holding-heart text-xl"></i>
             </div>
             <h3 className="text-lg font-bold font-serif mb-2 text-gray-800">Transparent Pricing</h3>
             <p className="text-gray-600 text-sm">We provide competitive RTGS rates for bulk and digital transactions.</p>
          </div>
          <div className="p-6 bg-white rounded-lg shadow border-t-4 border-maroon-800">
             <div className="w-12 h-12 bg-maroon-100 rounded-full flex items-center justify-center text-maroon-800 mb-4 mx-auto md:mx-0">
               <i className="fas fa-truck-loading text-xl"></i>
             </div>
             <h3 className="text-lg font-bold font-serif mb-2 text-gray-800">Bulk Orders</h3>
             <p className="text-gray-600 text-sm">Specialized service for bulk gold and silver bullion orders with secure handling.</p>
          </div>
        </div>

      </main>

      {/* Admin Panel & Chat */}
      {showAdmin && <AdminPanel currentRates={rates} onClose={() => setShowAdmin(false)} />}
      <ChatWidget />
    </div>
  );
}

export default App;