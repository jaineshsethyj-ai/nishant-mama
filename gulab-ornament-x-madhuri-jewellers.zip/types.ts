export interface MetalRates {
  silverBatiya: number;
  silverRtgsBatiya: number;
  goldBread9950: number;
  goldBreadNumber9999: number;
  goldRtgsNumber9999: number;
  lastUpdated: string; // ISO string
}

export const DEFAULT_RATES: MetalRates = {
  silverBatiya: 84000,
  silverRtgsBatiya: 83850,
  goldBread9950: 72100,
  goldBreadNumber9999: 72500,
  goldRtgsNumber9999: 72450,
  lastUpdated: new Date().toISOString(),
};

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}