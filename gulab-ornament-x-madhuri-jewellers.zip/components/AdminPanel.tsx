import React, { useState } from 'react';
import { MetalRates } from '../types';
import { doc, setDoc } from "firebase/firestore";
import { db } from '../firebase';

interface AdminPanelProps {
  currentRates: MetalRates;
  onClose: () => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ currentRates, onClose }) => {
  const [rates, setRates] = useState<MetalRates>(currentRates);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setRates(prev => ({
      ...prev,
      [name]: parseFloat(value) || 0
    }));
  };

  const handleSave = async () => {
    setLoading(true);
    setError(null);
    try {
      const updatedRates = {
        ...rates,
        lastUpdated: new Date().toISOString()
      };
      
      await setDoc(doc(db, "rates", "current"), updatedRates);
      onClose();
    } catch (err: any) {
      console.error("Error updating rates:", err);
      // Friendly error for demo purposes if permissions fail
      if (err.code === 'permission-denied') {
        setError("Permission denied. You may need to update Firestore security rules to allow writes to 'rates/current'.");
      } else {
        setError("Failed to update rates. Please try again.");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-2xl max-w-md w-full p-6 relative">
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
          <i className="fas fa-times"></i>
        </button>
        
        <h2 className="text-2xl font-serif text-maroon-900 mb-6 border-b border-gold-200 pb-2">Update Trading Rates</h2>
        
        {error && (
          <div className="mb-4 p-3 bg-red-50 text-red-700 text-sm rounded border border-red-100">
            {error}
          </div>
        )}

        <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Silver Batiya (1kg)</label>
            <input 
              type="number" 
              name="silverBatiya" 
              value={rates.silverBatiya} 
              onChange={handleChange}
              className="w-full border border-gray-300 rounded px-3 py-2 focus:ring-2 focus:ring-gold-500 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Silver RTGS Batiya (1kg)</label>
            <input 
              type="number" 
              name="silverRtgsBatiya" 
              value={rates.silverRtgsBatiya} 
              onChange={handleChange}
              className="w-full border border-gray-300 rounded px-3 py-2 focus:ring-2 focus:ring-gold-500 focus:outline-none"
            />
          </div>
          <div className="border-t border-gray-200 my-2 pt-2"></div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Gold Bread 99.50 (10g)</label>
            <input 
              type="number" 
              name="goldBread9950" 
              value={rates.goldBread9950} 
              onChange={handleChange}
              className="w-full border border-gray-300 rounded px-3 py-2 focus:ring-2 focus:ring-gold-500 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Gold Bread Number 99.99 (10g)</label>
            <input 
              type="number" 
              name="goldBreadNumber9999" 
              value={rates.goldBreadNumber9999} 
              onChange={handleChange}
              className="w-full border border-gray-300 rounded px-3 py-2 focus:ring-2 focus:ring-gold-500 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Gold RTGS Number 99.99 (10g)</label>
            <input 
              type="number" 
              name="goldRtgsNumber9999" 
              value={rates.goldRtgsNumber9999} 
              onChange={handleChange}
              className="w-full border border-gray-300 rounded px-3 py-2 focus:ring-2 focus:ring-gold-500 focus:outline-none"
            />
          </div>
        </div>

        <div className="mt-6 flex justify-end space-x-3">
          <button 
            onClick={onClose}
            className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded"
          >
            Cancel
          </button>
          <button 
            onClick={handleSave}
            disabled={loading}
            className="px-6 py-2 bg-gradient-to-r from-gold-600 to-gold-500 text-white rounded shadow hover:shadow-lg disabled:opacity-50"
          >
            {loading ? 'Saving...' : 'Update Rates'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;