import React from 'react';

interface RateCardProps {
  title: string;
  purity: string;
  price: number;
  unit?: string;
  iconClass: string;
  trend?: 'up' | 'down' | 'stable';
  delay?: number;
}

const RateCard: React.FC<RateCardProps> = ({ 
  title, 
  purity, 
  price, 
  unit = "10g", 
  iconClass, 
  trend = 'stable',
  delay = 0 
}) => {
  return (
    <div 
      className="relative bg-white rounded-xl shadow-md md:shadow-xl overflow-hidden transform transition-all duration-700 hover:-translate-y-2 hover:shadow-2xl border border-gold-200 h-full flex flex-col justify-between"
      style={{ animationDelay: `${delay}ms` }}
    >
      {/* Background Icon */}
      <div className="absolute top-0 right-0 p-2 md:p-4 opacity-5 pointer-events-none">
        <i className={`${iconClass} text-5xl md:text-6xl text-gold-700`}></i>
      </div>
      
      <div className="p-4 md:p-6 flex-grow flex flex-col justify-center">
        {/* Header Section */}
        <div className="flex justify-between items-start mb-2 md:mb-4">
          <div className="z-10 pr-2">
            <h3 className="text-maroon-900 font-serif text-base md:text-xl font-bold tracking-wide uppercase leading-tight">{title}</h3>
            <div className="flex items-center gap-1 mt-1">
              <span className="bg-gold-100 text-gold-800 px-1.5 py-0.5 rounded text-xs md:text-sm font-bold tracking-wide">{purity}</span>
            </div>
          </div>
          <div className={`rounded-full p-1.5 md:p-2 shadow-sm flex-shrink-0 ${trend === 'up' ? 'bg-green-100 text-green-700' : trend === 'down' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-500'}`}>
            <i className={`fas fa-arrow-${trend === 'up' ? 'up' : trend === 'down' ? 'down' : 'right'} text-xs md:text-base`}></i>
          </div>
        </div>

        {/* Price Section */}
        <div className="mt-1 md:mt-2">
          <div className="flex items-baseline">
            <span className="text-2xl md:text-4xl font-bold text-maroon-900 font-sans tracking-tight">₹{price.toLocaleString('en-IN')}</span>
          </div>
          <p className="text-gray-500 text-xs md:text-sm font-medium mt-0.5">Per {unit} <span className="text-gray-400 text-[10px] md:text-xs">(Excl. GST)</span></p>
        </div>
      </div>
      
      <div className="h-1.5 md:h-2 w-full gold-gradient"></div>
    </div>
  );
};

export default RateCard;