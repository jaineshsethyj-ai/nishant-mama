import { GoogleGenAI } from "@google/genai";

// NOTE: In a real production app, you should not expose the API key on the client side.
// Since this is a generated demo using the user's environment variable assumption:
const apiKey = process.env.API_KEY || ''; 

const ai = new GoogleGenAI({ apiKey });

export const getGeminiResponse = async (
  prompt: string, 
  history: {role: 'user' | 'model', text: string}[]
): Promise<string> => {
  if (!apiKey) {
    return "I'm sorry, the AI service is not configured (missing API Key).";
  }

  try {
    const model = 'gemini-2.5-flash';
    
    // Format history for the API
    // The API expects a specific history format if using chat, but for simple single-turn or manual history management:
    const chat = ai.chats.create({
      model: model,
      config: {
        systemInstruction: "You are a polite, knowledgeable jewellery assistant for 'Gulab Ornament X Madhuri Jewellers'. You help customers understand our specific trading rates: Silver Batiya (Bars), Silver RTGS Batiya, Gold Bread 99.50, Gold Bread 99.99, and Gold RTGS rates. Keep answers concise, professional, and elegant.",
      },
      history: history.map(msg => ({
        role: msg.role,
        parts: [{ text: msg.text }]
      }))
    });

    const result = await chat.sendMessage({ message: prompt });
    return result.text || "I apologize, I couldn't generate a response.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I am currently experiencing high traffic. Please try again later.";
  }
};