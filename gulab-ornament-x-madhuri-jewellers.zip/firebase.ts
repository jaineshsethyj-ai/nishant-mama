import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getFirestore } from "firebase/firestore";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCo94VjbHBUQ-t8DrsGklTDnviFlf9Rk-A",
  authDomain: "nishant-mama.firebaseapp.com",
  projectId: "nishant-mama",
  storageBucket: "nishant-mama.firebasestorage.app",
  messagingSenderId: "844665904154",
  appId: "1:844665904154:web:a738cdcb74c713b5dd85a3",
  measurementId: "G-GWQS16PE6Y"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const db = getFirestore(app);

export { app, analytics, db };
